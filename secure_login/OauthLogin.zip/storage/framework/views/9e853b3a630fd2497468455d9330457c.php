<?php echo e($slot); ?>

<?php /**PATH /mnt/c/Workspace/secure-login/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>